package net.minecraft.client.audio;

public interface ISoundEventAccessor
{
    int func_148721_a();

    Object func_148720_g();
}
