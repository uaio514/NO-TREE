package net.minecraft.client.renderer;

import java.awt.image.BufferedImage;

public interface IImageBuffer
{
    BufferedImage parseUserSkin(BufferedImage p_78432_1_);

    void func_152634_a();
}
